import React from 'react'

function Header() {
  return (
    <div className='header'>
        <div className='in-header'>
            <p>It’s your last day to save | Snap up courses from just ₹399 while you can. <span id="x"><i class="fa-solid fa-x"></i></span> </p>
            <p>Ends in 8h 58m 8s.</p>
        </div>
        
    </div>
  )
}

export default Header